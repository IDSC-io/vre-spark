networkx.utils.contextmanagers.reversed
=======================================

.. currentmodule:: networkx.utils.contextmanagers

.. autofunction:: reversed