networkx.utils.misc.groups
==========================

.. currentmodule:: networkx.utils.misc

.. autofunction:: groups