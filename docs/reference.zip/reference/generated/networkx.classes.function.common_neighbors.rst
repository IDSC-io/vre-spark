networkx.classes.function.common\_neighbors
===========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: common_neighbors