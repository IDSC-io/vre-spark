networkx.classes.function.is\_negatively\_weighted
==================================================

.. currentmodule:: networkx.classes.function

.. autofunction:: is_negatively_weighted