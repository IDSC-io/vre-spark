networkx.utils.misc.make\_list\_of\_ints
========================================

.. currentmodule:: networkx.utils.misc

.. autofunction:: make_list_of_ints