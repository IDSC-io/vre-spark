networkx.utils.random\_sequence.zipf\_rv
========================================

.. currentmodule:: networkx.utils.random_sequence

.. autofunction:: zipf_rv