networkx.classes.function.set\_edge\_attributes
===============================================

.. currentmodule:: networkx.classes.function

.. autofunction:: set_edge_attributes