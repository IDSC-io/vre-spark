networkx.classes.function.edge\_subgraph
========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: edge_subgraph