networkx.utils.decorators.open\_file
====================================

.. currentmodule:: networkx.utils.decorators

.. autofunction:: open_file