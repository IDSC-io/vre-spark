networkx.classes.function.is\_frozen
====================================

.. currentmodule:: networkx.classes.function

.. autofunction:: is_frozen