networkx.classes.function.freeze
================================

.. currentmodule:: networkx.classes.function

.. autofunction:: freeze