networkx.utils.decorators.random\_state
=======================================

.. currentmodule:: networkx.utils.decorators

.. autofunction:: random_state