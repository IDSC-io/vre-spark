networkx.utils.misc.generate\_unique\_node
==========================================

.. currentmodule:: networkx.utils.misc

.. autofunction:: generate_unique_node