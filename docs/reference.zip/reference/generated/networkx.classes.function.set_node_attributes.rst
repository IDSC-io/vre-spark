networkx.classes.function.set\_node\_attributes
===============================================

.. currentmodule:: networkx.classes.function

.. autofunction:: set_node_attributes