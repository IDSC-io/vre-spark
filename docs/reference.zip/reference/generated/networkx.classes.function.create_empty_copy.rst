networkx.classes.function.create\_empty\_copy
=============================================

.. currentmodule:: networkx.classes.function

.. autofunction:: create_empty_copy