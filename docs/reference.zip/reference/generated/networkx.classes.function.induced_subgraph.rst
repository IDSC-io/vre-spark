networkx.classes.function.induced\_subgraph
===========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: induced_subgraph