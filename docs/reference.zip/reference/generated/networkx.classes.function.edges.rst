networkx.classes.function.edges
===============================

.. currentmodule:: networkx.classes.function

.. autofunction:: edges