networkx.utils.misc.flatten
===========================

.. currentmodule:: networkx.utils.misc

.. autofunction:: flatten