networkx.utils.random\_sequence.weighted\_choice
================================================

.. currentmodule:: networkx.utils.random_sequence

.. autofunction:: weighted_choice