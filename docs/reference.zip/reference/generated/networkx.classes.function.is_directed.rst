networkx.classes.function.is\_directed
======================================

.. currentmodule:: networkx.classes.function

.. autofunction:: is_directed