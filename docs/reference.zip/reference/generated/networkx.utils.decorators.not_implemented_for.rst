networkx.utils.decorators.not\_implemented\_for
===============================================

.. currentmodule:: networkx.utils.decorators

.. autofunction:: not_implemented_for