networkx.utils.misc.default\_opener
===================================

.. currentmodule:: networkx.utils.misc

.. autofunction:: default_opener