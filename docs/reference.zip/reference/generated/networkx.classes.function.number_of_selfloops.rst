networkx.classes.function.number\_of\_selfloops
===============================================

.. currentmodule:: networkx.classes.function

.. autofunction:: number_of_selfloops