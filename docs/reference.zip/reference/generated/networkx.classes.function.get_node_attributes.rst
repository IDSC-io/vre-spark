networkx.classes.function.get\_node\_attributes
===============================================

.. currentmodule:: networkx.classes.function

.. autofunction:: get_node_attributes