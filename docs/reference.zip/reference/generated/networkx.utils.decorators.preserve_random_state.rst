networkx.utils.decorators.preserve\_random\_state
=================================================

.. currentmodule:: networkx.utils.decorators

.. autofunction:: preserve_random_state