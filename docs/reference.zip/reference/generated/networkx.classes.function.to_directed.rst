networkx.classes.function.to\_directed
======================================

.. currentmodule:: networkx.classes.function

.. autofunction:: to_directed