networkx.utils.random\_sequence.discrete\_sequence
==================================================

.. currentmodule:: networkx.utils.random_sequence

.. autofunction:: discrete_sequence