networkx.utils.rcm.cuthill\_mckee\_ordering
===========================================

.. currentmodule:: networkx.utils.rcm

.. autofunction:: cuthill_mckee_ordering