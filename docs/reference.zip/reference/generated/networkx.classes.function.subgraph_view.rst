networkx.classes.function.subgraph\_view
========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: subgraph_view