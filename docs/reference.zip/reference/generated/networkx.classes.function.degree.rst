networkx.classes.function.degree
================================

.. currentmodule:: networkx.classes.function

.. autofunction:: degree