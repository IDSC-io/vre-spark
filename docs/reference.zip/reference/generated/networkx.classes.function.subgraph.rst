networkx.classes.function.subgraph
==================================

.. currentmodule:: networkx.classes.function

.. autofunction:: subgraph