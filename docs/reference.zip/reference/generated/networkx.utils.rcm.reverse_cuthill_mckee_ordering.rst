networkx.utils.rcm.reverse\_cuthill\_mckee\_ordering
====================================================

.. currentmodule:: networkx.utils.rcm

.. autofunction:: reverse_cuthill_mckee_ordering