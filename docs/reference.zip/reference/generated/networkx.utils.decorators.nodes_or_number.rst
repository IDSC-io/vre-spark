networkx.utils.decorators.nodes\_or\_number
===========================================

.. currentmodule:: networkx.utils.decorators

.. autofunction:: nodes_or_number