networkx.classes.function.selfloop\_edges
=========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: selfloop_edges