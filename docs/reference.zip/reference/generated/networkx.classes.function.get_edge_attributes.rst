networkx.classes.function.get\_edge\_attributes
===============================================

.. currentmodule:: networkx.classes.function

.. autofunction:: get_edge_attributes