networkx.utils.misc.iterable
============================

.. currentmodule:: networkx.utils.misc

.. autofunction:: iterable