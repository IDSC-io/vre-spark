networkx.utils.misc.is\_string\_like
====================================

.. currentmodule:: networkx.utils.misc

.. autofunction:: is_string_like