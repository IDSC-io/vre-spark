networkx.classes.function.number\_of\_edges
===========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: number_of_edges