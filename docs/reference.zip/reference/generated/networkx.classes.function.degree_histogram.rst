networkx.classes.function.degree\_histogram
===========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: degree_histogram