networkx.classes.function.number\_of\_nodes
===========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: number_of_nodes