networkx.classes.function.is\_weighted
======================================

.. currentmodule:: networkx.classes.function

.. autofunction:: is_weighted