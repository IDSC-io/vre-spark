networkx.classes.function.reverse\_view
=======================================

.. currentmodule:: networkx.classes.function

.. autofunction:: reverse_view