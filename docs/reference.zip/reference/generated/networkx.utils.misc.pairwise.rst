networkx.utils.misc.pairwise
============================

.. currentmodule:: networkx.utils.misc

.. autofunction:: pairwise