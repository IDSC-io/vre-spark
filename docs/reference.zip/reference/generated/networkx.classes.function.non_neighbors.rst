networkx.classes.function.non\_neighbors
========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: non_neighbors