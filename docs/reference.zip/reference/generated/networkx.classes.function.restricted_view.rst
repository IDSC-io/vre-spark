networkx.classes.function.restricted\_view
==========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: restricted_view