networkx.utils.random\_sequence.powerlaw\_sequence
==================================================

.. currentmodule:: networkx.utils.random_sequence

.. autofunction:: powerlaw_sequence