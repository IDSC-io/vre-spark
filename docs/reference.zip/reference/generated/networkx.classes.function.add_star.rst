networkx.classes.function.add\_star
===================================

.. currentmodule:: networkx.classes.function

.. autofunction:: add_star