networkx.classes.function.is\_empty
===================================

.. currentmodule:: networkx.classes.function

.. autofunction:: is_empty