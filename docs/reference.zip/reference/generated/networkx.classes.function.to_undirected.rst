networkx.classes.function.to\_undirected
========================================

.. currentmodule:: networkx.classes.function

.. autofunction:: to_undirected