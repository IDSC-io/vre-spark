networkx.classes.function.add\_path
===================================

.. currentmodule:: networkx.classes.function

.. autofunction:: add_path