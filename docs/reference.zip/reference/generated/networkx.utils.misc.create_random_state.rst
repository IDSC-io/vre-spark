networkx.utils.misc.create\_random\_state
=========================================

.. currentmodule:: networkx.utils.misc

.. autofunction:: create_random_state