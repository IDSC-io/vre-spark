networkx.algorithms.centrality.betweenness\_centrality\_subset
==============================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: betweenness_centrality_subset