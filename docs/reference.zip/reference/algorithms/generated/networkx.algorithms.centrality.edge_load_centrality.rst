networkx.algorithms.centrality.edge\_load\_centrality
=====================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: edge_load_centrality