networkx.algorithms.centrality.group\_betweenness\_centrality
=============================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: group_betweenness_centrality