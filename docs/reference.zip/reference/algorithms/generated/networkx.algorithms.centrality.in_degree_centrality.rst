networkx.algorithms.centrality.in\_degree\_centrality
=====================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: in_degree_centrality