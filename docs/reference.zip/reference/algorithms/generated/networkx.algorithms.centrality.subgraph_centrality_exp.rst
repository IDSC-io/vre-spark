networkx.algorithms.centrality.subgraph\_centrality\_exp
========================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: subgraph_centrality_exp