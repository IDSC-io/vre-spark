networkx.algorithms.centrality.edge\_betweenness\_centrality
============================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: edge_betweenness_centrality