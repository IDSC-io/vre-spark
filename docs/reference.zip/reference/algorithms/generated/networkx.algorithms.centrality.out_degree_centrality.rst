networkx.algorithms.centrality.out\_degree\_centrality
======================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: out_degree_centrality