networkx.algorithms.centrality.group\_in\_degree\_centrality
============================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: group_in_degree_centrality