networkx.algorithms.centrality.betweenness\_centrality
======================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: betweenness_centrality