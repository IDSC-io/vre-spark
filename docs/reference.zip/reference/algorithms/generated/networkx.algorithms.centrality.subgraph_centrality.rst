networkx.algorithms.centrality.subgraph\_centrality
===================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: subgraph_centrality