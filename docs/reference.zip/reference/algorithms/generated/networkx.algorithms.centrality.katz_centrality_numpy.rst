networkx.algorithms.centrality.katz\_centrality\_numpy
======================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: katz_centrality_numpy