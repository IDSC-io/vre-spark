networkx.algorithms.centrality.current\_flow\_betweenness\_centrality
=====================================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: current_flow_betweenness_centrality