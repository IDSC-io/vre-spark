networkx.algorithms.centrality.estrada\_index
=============================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: estrada_index