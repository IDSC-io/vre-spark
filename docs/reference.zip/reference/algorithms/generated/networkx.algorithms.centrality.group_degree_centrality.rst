networkx.algorithms.centrality.group\_degree\_centrality
========================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: group_degree_centrality