networkx.algorithms.centrality.communicability\_betweenness\_centrality
=======================================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: communicability_betweenness_centrality