networkx.algorithms.centrality.incremental\_closeness\_centrality
=================================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: incremental_closeness_centrality