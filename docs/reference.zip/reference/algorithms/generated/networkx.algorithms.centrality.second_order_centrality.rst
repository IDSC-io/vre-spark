networkx.algorithms.centrality.second\_order\_centrality
========================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: second_order_centrality