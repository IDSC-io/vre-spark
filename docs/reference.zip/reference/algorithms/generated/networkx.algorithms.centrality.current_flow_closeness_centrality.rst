networkx.algorithms.centrality.current\_flow\_closeness\_centrality
===================================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: current_flow_closeness_centrality