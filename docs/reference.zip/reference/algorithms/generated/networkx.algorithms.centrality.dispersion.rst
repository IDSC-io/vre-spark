networkx.algorithms.centrality.dispersion
=========================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: dispersion