networkx.algorithms.centrality.local\_reaching\_centrality
==========================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: local_reaching_centrality