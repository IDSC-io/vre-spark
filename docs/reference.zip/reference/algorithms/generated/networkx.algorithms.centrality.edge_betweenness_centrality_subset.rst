networkx.algorithms.centrality.edge\_betweenness\_centrality\_subset
====================================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: edge_betweenness_centrality_subset