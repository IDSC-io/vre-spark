networkx.algorithms.centrality.group\_out\_degree\_centrality
=============================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: group_out_degree_centrality