networkx.algorithms.centrality.load\_centrality
===============================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: load_centrality