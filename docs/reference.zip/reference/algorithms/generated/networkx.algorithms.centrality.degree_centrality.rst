networkx.algorithms.centrality.degree\_centrality
=================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: degree_centrality