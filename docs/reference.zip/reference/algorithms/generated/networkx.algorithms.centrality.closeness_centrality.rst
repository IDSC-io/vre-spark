networkx.algorithms.centrality.closeness\_centrality
====================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: closeness_centrality