networkx.algorithms.centrality.approximate\_current\_flow\_betweenness\_centrality
==================================================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: approximate_current_flow_betweenness_centrality