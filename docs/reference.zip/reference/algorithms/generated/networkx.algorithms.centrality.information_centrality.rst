networkx.algorithms.centrality.information\_centrality
======================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: information_centrality