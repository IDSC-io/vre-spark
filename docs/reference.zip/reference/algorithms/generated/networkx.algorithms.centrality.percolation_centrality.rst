networkx.algorithms.centrality.percolation\_centrality
======================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: percolation_centrality