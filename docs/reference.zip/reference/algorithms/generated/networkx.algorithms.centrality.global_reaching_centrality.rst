networkx.algorithms.centrality.global\_reaching\_centrality
===========================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: global_reaching_centrality