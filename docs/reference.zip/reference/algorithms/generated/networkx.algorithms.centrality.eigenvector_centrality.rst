networkx.algorithms.centrality.eigenvector\_centrality
======================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: eigenvector_centrality