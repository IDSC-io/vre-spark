networkx.algorithms.centrality.group\_closeness\_centrality
===========================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: group_closeness_centrality