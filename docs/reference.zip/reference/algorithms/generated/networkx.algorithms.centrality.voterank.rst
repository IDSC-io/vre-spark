networkx.algorithms.centrality.voterank
=======================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: voterank