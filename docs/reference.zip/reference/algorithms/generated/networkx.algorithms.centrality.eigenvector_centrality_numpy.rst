networkx.algorithms.centrality.eigenvector\_centrality\_numpy
=============================================================

.. currentmodule:: networkx.algorithms.centrality

.. autofunction:: eigenvector_centrality_numpy