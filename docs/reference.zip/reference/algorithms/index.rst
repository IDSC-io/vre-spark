.. _algorithms:

**********
Algorithms
**********

.. currentmodule:: networkx

.. toctree::
   :maxdepth: 2

   centrality
