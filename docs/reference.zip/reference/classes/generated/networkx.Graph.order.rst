networkx.Graph.order
====================

.. currentmodule:: networkx

.. automethod:: Graph.order