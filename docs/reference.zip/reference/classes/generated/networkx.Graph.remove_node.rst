networkx.Graph.remove\_node
===========================

.. currentmodule:: networkx

.. automethod:: Graph.remove_node