networkx.Graph.remove\_edges\_from
==================================

.. currentmodule:: networkx

.. automethod:: Graph.remove_edges_from