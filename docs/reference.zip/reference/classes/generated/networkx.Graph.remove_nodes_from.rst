networkx.Graph.remove\_nodes\_from
==================================

.. currentmodule:: networkx

.. automethod:: Graph.remove_nodes_from