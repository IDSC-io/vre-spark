networkx.Graph.adjacency
========================

.. currentmodule:: networkx

.. automethod:: Graph.adjacency