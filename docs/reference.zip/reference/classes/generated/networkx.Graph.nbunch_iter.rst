networkx.Graph.nbunch\_iter
===========================

.. currentmodule:: networkx

.. automethod:: Graph.nbunch_iter