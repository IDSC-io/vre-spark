networkx.Graph.add\_edge
========================

.. currentmodule:: networkx

.. automethod:: Graph.add_edge