networkx.classes.graphviews.generic\_graph\_view
================================================

.. currentmodule:: networkx.classes.graphviews

.. autofunction:: generic_graph_view