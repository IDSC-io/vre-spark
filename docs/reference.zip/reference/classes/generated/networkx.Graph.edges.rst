networkx.Graph.edges
====================

.. currentmodule:: networkx

.. autoproperty:: Graph.edges