networkx.Graph.\_\_init\_\_
===========================

.. currentmodule:: networkx

.. automethod:: Graph.__init__