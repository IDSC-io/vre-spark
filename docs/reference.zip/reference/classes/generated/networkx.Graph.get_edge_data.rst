networkx.Graph.get\_edge\_data
==============================

.. currentmodule:: networkx

.. automethod:: Graph.get_edge_data