networkx.Graph.degree
=====================

.. currentmodule:: networkx

.. autoproperty:: Graph.degree