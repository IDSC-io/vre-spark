networkx.Graph.add\_node
========================

.. currentmodule:: networkx

.. automethod:: Graph.add_node