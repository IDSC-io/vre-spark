networkx.Graph.subgraph
=======================

.. currentmodule:: networkx

.. automethod:: Graph.subgraph