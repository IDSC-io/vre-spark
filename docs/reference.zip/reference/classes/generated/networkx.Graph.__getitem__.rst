networkx.Graph.\_\_getitem\_\_
==============================

.. currentmodule:: networkx

.. automethod:: Graph.__getitem__