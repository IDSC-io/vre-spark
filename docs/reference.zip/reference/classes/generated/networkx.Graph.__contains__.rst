networkx.Graph.\_\_contains\_\_
===============================

.. currentmodule:: networkx

.. automethod:: Graph.__contains__