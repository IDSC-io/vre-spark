networkx.Graph.add\_weighted\_edges\_from
=========================================

.. currentmodule:: networkx

.. automethod:: Graph.add_weighted_edges_from