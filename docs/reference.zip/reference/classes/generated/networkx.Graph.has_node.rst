networkx.Graph.has\_node
========================

.. currentmodule:: networkx

.. automethod:: Graph.has_node