networkx.classes.graphviews.subgraph\_view
==========================================

.. currentmodule:: networkx.classes.graphviews

.. autofunction:: subgraph_view