networkx.Graph.update
=====================

.. currentmodule:: networkx

.. automethod:: Graph.update