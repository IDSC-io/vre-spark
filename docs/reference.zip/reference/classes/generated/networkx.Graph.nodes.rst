networkx.Graph.nodes
====================

.. currentmodule:: networkx

.. autoproperty:: Graph.nodes