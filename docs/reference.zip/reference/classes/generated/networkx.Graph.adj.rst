networkx.Graph.adj
==================

.. currentmodule:: networkx

.. autoproperty:: Graph.adj