networkx.Graph.edge\_subgraph
=============================

.. currentmodule:: networkx

.. automethod:: Graph.edge_subgraph