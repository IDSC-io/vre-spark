networkx.Graph.copy
===================

.. currentmodule:: networkx

.. automethod:: Graph.copy