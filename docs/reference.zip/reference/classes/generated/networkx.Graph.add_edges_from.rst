networkx.Graph.add\_edges\_from
===============================

.. currentmodule:: networkx

.. automethod:: Graph.add_edges_from