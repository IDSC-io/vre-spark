networkx.Graph.number\_of\_edges
================================

.. currentmodule:: networkx

.. automethod:: Graph.number_of_edges