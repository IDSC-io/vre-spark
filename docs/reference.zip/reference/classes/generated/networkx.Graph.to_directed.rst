networkx.Graph.to\_directed
===========================

.. currentmodule:: networkx

.. automethod:: Graph.to_directed