networkx.classes.graphviews.reverse\_view
=========================================

.. currentmodule:: networkx.classes.graphviews

.. autofunction:: reverse_view