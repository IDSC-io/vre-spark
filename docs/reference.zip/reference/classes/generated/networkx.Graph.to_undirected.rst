networkx.Graph.to\_undirected
=============================

.. currentmodule:: networkx

.. automethod:: Graph.to_undirected