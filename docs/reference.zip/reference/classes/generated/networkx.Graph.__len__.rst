networkx.Graph.\_\_len\_\_
==========================

.. currentmodule:: networkx

.. automethod:: Graph.__len__