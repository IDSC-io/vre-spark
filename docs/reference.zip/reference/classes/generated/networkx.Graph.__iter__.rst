networkx.Graph.\_\_iter\_\_
===========================

.. currentmodule:: networkx

.. automethod:: Graph.__iter__