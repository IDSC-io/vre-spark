networkx.Graph.clear
====================

.. currentmodule:: networkx

.. automethod:: Graph.clear