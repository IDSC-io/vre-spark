networkx.Graph.number\_of\_nodes
================================

.. currentmodule:: networkx

.. automethod:: Graph.number_of_nodes