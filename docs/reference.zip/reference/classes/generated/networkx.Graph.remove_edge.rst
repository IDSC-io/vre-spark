networkx.Graph.remove\_edge
===========================

.. currentmodule:: networkx

.. automethod:: Graph.remove_edge