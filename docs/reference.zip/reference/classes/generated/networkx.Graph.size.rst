networkx.Graph.size
===================

.. currentmodule:: networkx

.. automethod:: Graph.size