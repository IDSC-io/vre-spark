networkx.readwrite.adjlist.read\_adjlist
========================================

.. currentmodule:: networkx.readwrite.adjlist

.. autofunction:: read_adjlist