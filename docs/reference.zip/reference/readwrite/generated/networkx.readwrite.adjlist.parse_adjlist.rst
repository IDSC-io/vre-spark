networkx.readwrite.adjlist.parse\_adjlist
=========================================

.. currentmodule:: networkx.readwrite.adjlist

.. autofunction:: parse_adjlist