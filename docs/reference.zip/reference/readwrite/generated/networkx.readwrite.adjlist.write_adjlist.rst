networkx.readwrite.adjlist.write\_adjlist
=========================================

.. currentmodule:: networkx.readwrite.adjlist

.. autofunction:: write_adjlist