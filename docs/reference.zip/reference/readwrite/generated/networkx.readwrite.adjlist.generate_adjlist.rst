networkx.readwrite.adjlist.generate\_adjlist
============================================

.. currentmodule:: networkx.readwrite.adjlist

.. autofunction:: generate_adjlist