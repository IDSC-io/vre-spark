.. _readwrite:

**************************
Reading and writing graphs
**************************

.. toctree::
   :maxdepth: 2

   adjlist
   neat.trees
